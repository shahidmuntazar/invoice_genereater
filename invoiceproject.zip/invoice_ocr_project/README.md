# Invoice OCR CLI

A small local-first Python CLI that runs Tesseract OCR on invoice images, extracts labelled fields, validates records, stores valid invoices in SQLite, and emits a JSON review report. It deliberately sends missing/uncertain fields to `needs_review` instead of guessing.

## Requirements

- Python 3.10+
- Tesseract OCR installed and available on `PATH`
- No third-party Python runtime packages

### Install Tesseract

- **Ubuntu/Debian:** `sudo apt-get update && sudo apt-get install -y tesseract-ocr`
- **macOS (Homebrew):** `brew install tesseract`
- **Windows:** install the Tesseract OCR distribution for Windows, then add its install directory to `PATH`. If it is not on `PATH`, pass `--tesseract "C:\\path\\to\\tesseract.exe"`.

## Run

Put the four supplied PNGs in `fixtures/` (or another directory), then from this repository root:

```bash
python -m invoice_ocr fixtures --db data/invoices.sqlite3 --output output/report.json
```

The CLI writes `filename.png.ocr.txt` beside each source image, stores valid invoices in SQLite, records each processed source scan in `source_scans`, and writes a JSON report. OCR failures are isolated per image.

## Test

```bash
python -m unittest discover -s tests -v
```

Tests use fixed OCR text and do not depend on the installed Tesseract version.

## Data model and idempotency

- `schema.sql` documents the SQLite schema (the CLI also initializes it automatically). `invoices` has a unique key on `(invoice_number, vendor, invoice_date, currency)`. This represents an invoice identity without relying on a scan filename, which changes between scans. If a real source system provides a stable vendor tax ID or invoice UUID, prefer that as part of the key. Conflicting amounts for an existing key should be surfaced as a review conflict in a production version rather than silently accepted.
- `source_scans` uses `source_filename` as a unique key and points to the normalized invoice row when valid. Multiple scans can point to one invoice, so a repeated scan does not create another invoice record and traceability is retained. Filenames are assumed unique within the processed collection; production deployments should use a relative path plus content hash or a durable source ID.
- Amounts are stored as canonical decimal strings, parsed and compared using `Decimal`, never binary floats. SQLite does not have a fixed-precision decimal storage type; strings avoid floating-point conversion. A production database could store integer minor units or use a database with a fixed-precision `NUMERIC` type.

## Extraction assumptions and limitations

- The parser expects labels such as `Invoice Number`, `Vendor`, `Invoice Date`, `Subtotal`, `Tax`/`GST`/`VAT`, and `Total`. It is intentionally conservative and not a general-purpose invoice understanding model.
- Numeric dates where both day and month are 1–12 and differ (e.g. `01/10/2026`) are marked for review rather than silently assuming a locale. ISO dates are unambiguous.
- Currency symbols are mapped to common ISO codes. A symbol such as `$` is not globally unique; production logic should use vendor or locale context and flag ambiguity.
- Reconciliation currently checks `subtotal + tax == total`. Discounts, shipping, withholding, rounding policies, multiple tax lines, and credits need explicit rules.
- Re-running a directory is idempotent for filenames and invoice keys, but the code currently upserts the scan row by filename. It does not yet report a conflicting set of amounts for an already-known invoice key.

## Human correction and retries

Add a review command or small web UI that lists `needs_review` records, allows a reviewer to correct fields while preserving the original OCR text, and stores reviewer, timestamp, and before/after values in an audit table. Add bounded OCR retries with image preprocessing (deskew, contrast, thresholding) and configurable Tesseract page segmentation modes. Avoid automatically retrying deterministic parse failures without changing the OCR/preprocessing strategy.

## Sample output status

`output/sample-report.json` is illustrative output generated from fixed example OCR text. `output/uploaded-fixtures-report.json` is the actual local Tesseract output for the two images included in `fixtures/` (`invoice-101-copy.png` and `invoice-103-review.png`). The other two hiring images were not supplied in this workspace; add them to `fixtures/` and rerun the command to process all four.

## Python/database issue explanation — personalize before submitting

Do not claim the following as a past personal experience unless it is true. A relevant example you can adapt from your own work: “I fixed a duplicate-import bug caused by checking for an existing row in Python before inserting it. Two workers could both pass the check and insert the same logical record. I moved the invariant into a database UNIQUE constraint and used an atomic insert/upsert, then added a repeat-import test. My contribution was [describe your actual code/debugging]; the team handled [describe the actual review/deployment or other team work].” Replace this with a truthful example from your own experience and clearly separate your contribution from the team’s.
