import sqlite3
import tempfile
import unittest
from pathlib import Path
from invoice_ocr.core import extract_fields, init_db, persist_result

VALID_TEXT = """Vendor: Acme Supplies
Invoice Number: INV-101
Invoice Date: 2025-01-15
Currency: INR
Subtotal: 1000.00
Tax: 180.00
Total: 1180.00
"""

class InvoiceTests(unittest.TestCase):
    def test_valid_field_validation(self):
        result = extract_fields("scan.png", VALID_TEXT)
        self.assertEqual(result.status, "valid")
        self.assertEqual(result.invoice_date, "2025-01-15")
        self.assertEqual(result.total, "1180.00")
        self.assertEqual(result.review_reasons, [])

    def test_duplicate_repeated_import_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "invoices.sqlite3"
            result = extract_fields("scan.png", VALID_TEXT)
            persist_result(db, result)
            persist_result(db, result)
            with sqlite3.connect(db) as conn:
                self.assertEqual(conn.execute("SELECT count(*) FROM invoices").fetchone()[0], 1)
                self.assertEqual(conn.execute("SELECT count(*) FROM source_scans").fetchone()[0], 1)

    def test_incomplete_ambiguous_input_needs_review(self):
        result = extract_fields("bad.png", "Invoice Number: INV-103\nTotal: 99.00")
        self.assertEqual(result.status, "needs_review")
        self.assertIn("missing_or_ambiguous_vendor", result.review_reasons)
        self.assertIn("missing_or_ambiguous_subtotal", result.review_reasons)

    def test_ambiguous_numeric_date_is_not_guessed(self):
        text = VALID_TEXT.replace("2025-01-15", "01/10/2026")
        result = extract_fields("ambiguous-date.png", text)
        self.assertEqual(result.status, "needs_review")
        self.assertIsNone(result.invoice_date)
        self.assertIn("missing_or_ambiguous_invoice_date", result.review_reasons)

    def test_duplicate_invoice_keeps_both_source_scans(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "invoices.sqlite3"
            a = extract_fields("first.png", VALID_TEXT)
            b = extract_fields("second.png", VALID_TEXT)
            persist_result(db, a)
            persist_result(db, b)
            with sqlite3.connect(db) as conn:
                self.assertEqual(conn.execute("SELECT count(*) FROM invoices").fetchone()[0], 1)
                self.assertEqual(conn.execute("SELECT count(*) FROM source_scans").fetchone()[0], 2)

if __name__ == "__main__":
    unittest.main()
