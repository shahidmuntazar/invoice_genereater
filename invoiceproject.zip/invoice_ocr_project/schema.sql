PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY,
    invoice_number TEXT NOT NULL,
    vendor TEXT NOT NULL,
    invoice_date TEXT NOT NULL,
    currency TEXT NOT NULL,
    subtotal TEXT NOT NULL,
    tax TEXT NOT NULL,
    total TEXT NOT NULL,
    UNIQUE(invoice_number, vendor, invoice_date, currency)
);

CREATE TABLE IF NOT EXISTS source_scans (
    id INTEGER PRIMARY KEY,
    source_filename TEXT NOT NULL UNIQUE,
    raw_text TEXT NOT NULL,
    status TEXT NOT NULL,
    review_reasons_json TEXT NOT NULL,
    invoice_id INTEGER REFERENCES invoices(id),
    processed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
