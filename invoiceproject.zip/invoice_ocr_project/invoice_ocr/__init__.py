"""Local invoice OCR and validation CLI."""
