import argparse
from pathlib import Path
from .core import process_directory


def main() -> None:
    parser = argparse.ArgumentParser(description="OCR invoices, validate fields, and store valid records in SQLite")
    parser.add_argument("input_dir", type=Path, help="Directory containing invoice image files")
    parser.add_argument("--db", type=Path, default=Path("data/invoices.sqlite3"))
    parser.add_argument("--output", type=Path, default=Path("output/report.json"))
    parser.add_argument("--tesseract", default="tesseract", help="Tesseract executable name/path")
    args = parser.parse_args()
    results = process_directory(args.input_dir, args.db, args.output, args.tesseract)
    valid = sum(r["status"] == "valid" for r in results)
    print(f"Processed {len(results)} image(s): {valid} valid, {len(results)-valid} needs review")
    print(f"Report: {args.output}\nDatabase: {args.db}")

if __name__ == "__main__":
    main()
