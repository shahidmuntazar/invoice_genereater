from __future__ import annotations

import re
import sqlite3
import subprocess
from dataclasses import asdict, dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable

FIELDS = ("invoice_number", "vendor", "invoice_date", "currency", "subtotal", "tax", "total")

@dataclass
class InvoiceResult:
    source_filename: str
    raw_text: str
    invoice_number: str | None = None
    vendor: str | None = None
    invoice_date: str | None = None
    currency: str | None = None
    subtotal: str | None = None
    tax: str | None = None
    total: str | None = None
    status: str = "needs_review"
    review_reasons: list[str] | None = None

    def to_dict(self) -> dict:
        result = asdict(self)
        result["review_reasons"] = self.review_reasons or []
        return result


def run_ocr(image_path: Path, executable: str = "tesseract") -> str:
    """Run local Tesseract OCR and return stdout; errors are handled per image by caller."""
    completed = subprocess.run(
        [executable, str(image_path), "stdout"], capture_output=True, text=True, check=True
    )
    return completed.stdout.strip()


def _capture(patterns: Iterable[str], text: str) -> str | None:
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip().rstrip(".,;:")
    return None


def _money(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = value.strip().replace(",", "").replace("₹", "").replace("$", "").replace("€", "")
    cleaned = re.sub(r"\b(?:INR|USD|EUR|GBP)\b", "", cleaned, flags=re.IGNORECASE).strip()
    try:
        amount = Decimal(cleaned)
    except InvalidOperation:
        return None
    if not amount.is_finite():
        return None
    return format(amount.quantize(Decimal("0.01")), "f")


def extract_fields(source_filename: str, raw_text: str) -> InvoiceResult:
    """Conservative label-based extraction; uncertain or absent fields are reviewed, not guessed."""
    result = InvoiceResult(source_filename=source_filename, raw_text=raw_text, review_reasons=[])
    result.invoice_number = _capture([
        r"(?:invoice\s*(?:number|no\.?|#)\s*[:#-]?\s*|invoice\s*[:#]\s*)([A-Z0-9][A-Z0-9/-]+)"
    ], raw_text)
    result.vendor = _capture([
        r"(?:vendor|supplier|seller|from)\s*[:\-]\s*(.+)"
    ], raw_text)
    raw_date = _capture([
        r"(?:invoice\s*)?date\s*[:\-]?\s*(\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})"
    ], raw_text)
    if raw_date:
        # Do not silently choose day/month or month/day when both interpretations are possible.
        numeric_date = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})", raw_date)
        ambiguous_order = bool(numeric_date and int(numeric_date.group(1)) <= 12
                                and int(numeric_date.group(2)) <= 12
                                and numeric_date.group(1) != numeric_date.group(2))
        if not ambiguous_order:
            for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%m-%d-%Y", "%d/%m/%y", "%m/%d/%y"):
                try:
                    result.invoice_date = date.fromisoformat(raw_date) .isoformat() if fmt == "%Y-%m-%d" and re.fullmatch(r"\d{4}-\d{1,2}-\d{1,2}", raw_date) else __import__("datetime").datetime.strptime(raw_date, fmt).date().isoformat()
                    break
                except ValueError:
                    continue
    currency = _capture([r"\b(INR|USD|EUR|GBP)\b", r"(₹|\$|€|£)"], raw_text)
    result.currency = {"₹": "INR", "$": "USD", "€": "EUR", "£": "GBP"}.get(currency, currency.upper() if currency else None)
    for field, labels in {
        "subtotal": r"(?:sub\s*total|subtotal)\s*[:\-]?\s*(?:INR|USD|EUR|GBP|₹|\$|€|£)?\s*([\d,]+(?:\.\d{1,2})?)",
        "tax": r"(?:tax|GST|VAT)\s*[:\-]?\s*(?:INR|USD|EUR|GBP|₹|\$|€|£)?\s*([\d,]+(?:\.\d{1,2})?)",
        "total": r"(?:grand\s*total|invoice\s*total|total\s*due|(?<!sub)\btotal\b)\s*[:\-]?\s*(?:INR|USD|EUR|GBP|₹|\$|€|£)?\s*([\d,]+(?:\.\d{1,2})?)",
    }.items():
        result.__dict__[field] = _money(_capture([labels], raw_text))
    validate(result)
    return result


def validate(result: InvoiceResult) -> InvoiceResult:
    reasons: list[str] = []
    for field in FIELDS:
        value = getattr(result, field)
        if value is None or (isinstance(value, str) and not value.strip()):
            reasons.append(f"missing_or_ambiguous_{field}")
    if result.invoice_date:
        try:
            date.fromisoformat(result.invoice_date)
        except ValueError:
            reasons.append("invalid_invoice_date")
    amounts = (result.subtotal, result.tax, result.total)
    if all(v is not None for v in amounts):
        if Decimal(result.subtotal) + Decimal(result.tax) != Decimal(result.total):
            reasons.append("subtotal_plus_tax_does_not_equal_total")
    result.review_reasons = sorted(set(reasons))
    result.status = "valid" if not result.review_reasons else "needs_review"
    return result


def init_db(db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY,
            invoice_number TEXT NOT NULL,
            vendor TEXT NOT NULL,
            invoice_date TEXT NOT NULL,
            currency TEXT NOT NULL,
            subtotal TEXT NOT NULL,
            tax TEXT NOT NULL,
            total TEXT NOT NULL,
            UNIQUE(invoice_number, vendor, invoice_date, currency)
        );
        CREATE TABLE IF NOT EXISTS source_scans (
            id INTEGER PRIMARY KEY,
            source_filename TEXT NOT NULL UNIQUE,
            raw_text TEXT NOT NULL,
            status TEXT NOT NULL,
            review_reasons_json TEXT NOT NULL,
            invoice_id INTEGER REFERENCES invoices(id),
            processed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)


def persist_result(db_path: Path, result: InvoiceResult) -> None:
    import json
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        invoice_id = None
        if result.status == "valid":
            key = (result.invoice_number, result.vendor, result.invoice_date, result.currency)
            conn.execute("""INSERT INTO invoices(invoice_number,vendor,invoice_date,currency,subtotal,tax,total)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(invoice_number,vendor,invoice_date,currency) DO NOTHING""",
                (*key, result.subtotal, result.tax, result.total))
            row = conn.execute("SELECT id FROM invoices WHERE invoice_number=? AND vendor=? AND invoice_date=? AND currency=?", key).fetchone()
            invoice_id = row[0] if row else None
        conn.execute("""INSERT INTO source_scans(source_filename,raw_text,status,review_reasons_json,invoice_id)
            VALUES(?,?,?,?,?) ON CONFLICT(source_filename) DO UPDATE SET raw_text=excluded.raw_text,
            status=excluded.status, review_reasons_json=excluded.review_reasons_json, invoice_id=excluded.invoice_id""",
            (result.source_filename, result.raw_text, result.status, json.dumps(result.review_reasons or []), invoice_id))


def process_directory(input_dir: Path, db_path: Path, output_path: Path, tesseract: str = "tesseract") -> list[dict]:
    import json
    results: list[InvoiceResult] = []
    input_dir = input_dir.resolve()
    for path in sorted(input_dir.iterdir()):
        if not path.is_file() or path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
            continue
        try:
            raw_text = run_ocr(path, tesseract)
            result = extract_fields(path.name, raw_text)
        except Exception as exc:
            result = InvoiceResult(source_filename=path.name, raw_text="", status="needs_review",
                                   review_reasons=[f"ocr_failed:{type(exc).__name__}: {exc}"])
        # Preserve raw OCR output as a sidecar, including empty text on OCR failure.
        try:
            path.with_suffix(path.suffix + ".ocr.txt").write_text(result.raw_text, encoding="utf-8")
        except OSError:
            result.review_reasons = (result.review_reasons or []) + ["could_not_write_ocr_sidecar"]
            result.status = "needs_review"
        persist_result(db_path, result)
        results.append(result)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps([r.to_dict() for r in results], indent=2, ensure_ascii=False), encoding="utf-8")
    return [r.to_dict() for r in results]
